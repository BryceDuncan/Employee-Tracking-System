//
//  Employee.cpp
//  btd180001Asg5
//
//  Created by Bryce Duncan on 3/20/20.
//  Copyright © 2020 Duncan Apps. All rights reserved.
//


#include "Employee.hpp"

void Employee::setEmployeeID(string ID)
{
   employeeID = ID;
}

void Employee::setLastName(string last)
{
   lastName = last;
}

void Employee::setFirstName(string first)
{
   firstName = first;
}

void Employee::setBirthday(string birthDate)
{
   birthday = birthDate;
}

void Employee::setGender(char gen)
{
   gender = gen;
}

void Employee::setStartDate(string start)
{
   startDate = start;
}

void Employee::setSalary(double pay)
{
   salary = pay;
}

string Employee::getEmployeeID() const
{
   return employeeID;
}

string Employee::getLastName() const
{
   return lastName;
}

string Employee::getFirstName() const
{
   return firstName;
}

string Employee::getBirthday() const
{
   return birthday;
}

char Employee::getGender() const
{
   return gender;
}

string Employee::getStartDate() const
{
   return startDate;
}

double Employee::getSalary() const
{
   return salary;
}
