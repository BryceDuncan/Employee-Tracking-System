// Written by:   Bryce Duncan
// For:          CS 1337.009, Assignment 5 - Simple Employee Tracking System
// Date Started: March 20th, 2020

// Program Description: This program tracks the information of employees with the use of classes

#include <iostream>
#include <iomanip>
#include <string>
#include "Employee.hpp"
#include "FileIO.hpp"

using namespace std;

//Function prototype
int newInfo(Employee* employeeData[], int counter);
void sortInfo(Employee* employeeData[], int counter);
void searchInfo(Employee* employeeData[], int counter);
int remove(Employee* employeeData[], int counter);


//Beginning of main()
int main()
{
   //Declaration of variables
   int menu;
   int counter;
   Employee* employeeData[100];
   
   //Initialization of variables
   menu = 0;
   
   //Reading in the File if it exists
   FileIO read;
   counter = read.readFile(employeeData);
   
   while (menu != 5)
   {
      menu = 0;
      
      //Menu for options
      cout << "1. Enter new employee information" << endl;
      cout << "2. Display all employee information in alphabetical order by last name" << endl;
      cout << "3. Look up an employee ID" << endl;
      cout << "4. Remove an Employee" << endl;
      cout << "5. Save all data to Employee.txt and exit" << endl;
   
      cin >> menu;
      
      //Switch menu for options
      switch (menu)
      {
            case 1:
            counter = newInfo(employeeData, counter);
            break;
            
            case 2:
            sortInfo(employeeData, counter);
            break;
            
            case 3:
            searchInfo(employeeData, counter);
            break;
            
            case 4:
            counter = remove(employeeData, counter);
            break;
            
            case 5:
            //cout << employeeData[counter]->getEmployeeID() << endl;
            read.writeFile(counter, employeeData);
            break;
            
         default:
            cout << "invalid Input." << endl;
            break;
      }
      //resets the cin to prevent error looping
      cin.clear();
      cin.ignore();
   }
   return 0;
}//End of main()

//Beginning of newInfo()
int newInfo(Employee* employeeData[], int counter)
{
   //Variable Declaration
   Employee *newEmployee;
   string id;
   string lastName;
   string firstName;
   string birthday;
   string startDate;
   char gender;
   double salary;
   bool idCheck;
   
   //Variable initialization
   idCheck = true;
   
   //UserID Check
   cout << "Please enter in the new employee's ID." << endl;
   cin >> id;
   
   //check if ID is null
   if (id.empty())
   {
      cout << "Nothing was entered in." << endl;
      idCheck = false;
   }
   
   //Check if ID is in use
   for(int check = 0; check <= counter; check++)
   {
      if (id == employeeData[check]->getEmployeeID())
      {
         idCheck = false;
         cout << "That ID is already in use!" << endl;
      }
   }
   
   //Requesting the rest of the information
   if (idCheck == true)
   {
      //New employee object
      newEmployee = new Employee(id);
      employeeData[counter+1] = newEmployee;
      
      //requesting the rest of the info
      cout << "Enter in the Last Name" << endl;
      cin >> lastName;
      cout << "Enter in the First Name" << endl;
      cin >> firstName;
      cout << "Enter in the Birthday" << endl;
      cin >> birthday;
      cout << "Enter in the Start Date" << endl;
      cin >> startDate;
      cout << "Enter in the Gender" << endl;
      cin >> gender;
      cout << "Enter in the Salary" << endl;
      cin >> salary;
      
      //Putting info into the object
      employeeData[counter+1]->setLastName(lastName);
      employeeData[counter+1]->setFirstName(firstName);
      employeeData[counter+1]->setBirthday(birthday);
      employeeData[counter+1]->setStartDate(startDate);
      employeeData[counter+1]->setGender(gender);
      employeeData[counter+1]->setSalary(salary);
   }
   counter++;
   return counter;
}
//End of newInfo()

//Beginning of sortInfo()
void sortInfo(Employee* employeeData[], int counter)
{
   //Variable declaration
   bool ifSorted;
   Employee* key;
   
   //Variable initialization
   ifSorted = false;
   
   //Name Sort
   do
   {
      ifSorted = false;
         
      //Sorting loop
      for (int  check = 0; check < counter; check++)
      {
         if (employeeData[check]->getLastName() > employeeData[check+1]->getLastName())
         {
            key = employeeData[check];
            employeeData[check] = employeeData[check+1];
            employeeData[check+1] = key;
            ifSorted = true;
         }
      }
   }
   while (ifSorted != false);
   
   //Display of information
   cout << "Employee ID: ";
   cout << setw(15) << "Last Name:";
   cout << setw(15) << "First Name:";
   cout << setw(12) << "Birthday:";
   cout << setw(8) << "Gender:";
   cout << setw(12) << "Start Date:";
   cout << setw(8) << "Salary:" << endl;
   for (int check = 0; check <= counter; check++)
   {
      cout << fixed << setprecision(0);
      cout << right << setw(12) << employeeData[check]->getEmployeeID();
      cout << right << setw(16) << employeeData[check]->getLastName();
      cout << right << setw(15) << employeeData[check]->getFirstName();
      cout << right << setw(12) << employeeData[check]->getBirthday();
      cout << right << setw(8) << employeeData[check]->getGender();
      cout << right << setw(12) << employeeData[check]->getStartDate();
      cout << right << setw(8) << employeeData[check]->getSalary() << endl;
   }
}
//End of sortInfo()

//Beginning of searchInfo()
void searchInfo(Employee* employeeData[], int counter)
{
   //Variable declaration
   string employeeID;
   bool ifFound;
   int key;
   
   //Variable initializatin
   ifFound = false;
   
   //Getting the input from the user
   cout << "Enter in the employee's ID" << endl;
   cin >> employeeID;
   
   //Looking for Data
   for (int check = 0; check <= counter; check++)
   {
      if (employeeID == employeeData[check]->getEmployeeID())
      {
         ifFound = true;
         key = check;
      }
   }
   
   //Display the info
   if (ifFound == true)
   {
      cout << "Employee ID: ";
      cout << setw(15) << "Last Name:";
      cout << setw(15) << "First Name:";
      cout << setw(12) << "Birthday:";
      cout << setw(8) << "Gender:";
      cout << setw(12) << "Start Date:";
      cout << setw(8) << "Salary:" << endl;
      cout << fixed << setprecision(0);
      cout << right << setw(12) << employeeData[key]->getEmployeeID();
      cout << right << setw(16) << employeeData[key]->getLastName();
      cout << right << setw(15) << employeeData[key]->getFirstName();
      cout << right << setw(12) << employeeData[key]->getBirthday();
      cout << right << setw(8) << employeeData[key]->getGender();
      cout << right << setw(12) << employeeData[key]->getStartDate();
      cout << right << setw(8) << employeeData[key]->getSalary() << endl;
   }
   else
   {
      cout << "The employee you were looking for could not be found." << endl;
   }
   
}
//End of searchInfo()

//Beginning of remove()
int remove(Employee* employeeData[], int check)
{
   //Variable declaration
   string idCheck;
   bool ifChecked;
   
   //Initialization of variables
   ifChecked = false;
   
   //Getting ID from the user
   cout << "Enter the ID of the Employee that needs to be removed" << endl;
   cin >> idCheck;
   
   //Looking for employee
   for (int counter = 0; counter <= check; counter++)
   {
      if (idCheck == employeeData[counter]->getEmployeeID())
      {
         ifChecked = true;
         delete employeeData[counter];
         for (;counter <= check; counter++)
         {
            employeeData[counter] = employeeData[counter+1];
         }
         check--;
      }
   }
   
   //If the employee is not found
   if (ifChecked == false)
   {
      cout << "The employee could not be found." << endl;
   }
   //If the employee was deleted
   else
   {
      cout << "The employee was successfully removed." << endl;
   }
   return check;
}
