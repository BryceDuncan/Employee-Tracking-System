//
//  Employee.hpp
//  btd180001Asg5
//
//  Created by Bryce Duncan on 3/20/20.
//  Copyright © 2020 Duncan Apps. All rights reserved.
//

#ifndef Employee_hpp
#define Employee_hpp

#include <stdio.h>
#include <string>

using namespace std;

class Employee
{
private:
   string employeeID;
   string lastName;
   string firstName;
   string birthday;
   string startDate;
   char gender;
   double salary;
   
public:
   void setEmployeeID(string);
   void setLastName(string);
   void setFirstName(string);
   void setBirthday(string);
   void setStartDate(string);
   void setGender(char);
   void setSalary(double);
   string getEmployeeID() const;
   string getLastName() const;
   string getFirstName() const;
   string getBirthday() const;
   string getStartDate() const;
   char getGender() const;
   double getSalary() const;
   
   Employee()
   {
      
   }
   
   Employee(string employeeID)
   {
      this->employeeID = employeeID;
   }
   
   Employee(string employeeID, string lastName, string firstName, string birthday, string startDate, char gender, double salary)
   {
      this->employeeID = employeeID;
      this->lastName = lastName;
      this->firstName = firstName;
      this->birthday = birthday;
      this->startDate = startDate;
      this->gender = gender;
      this->salary = salary;
   }
   
};


#endif /* Employee_hpp */

