//
//  O.cpp
//  btd180001Asg5
//
//  Created by Bryce Duncan on 3/20/20.
//  Copyright © 2020 Duncan Apps. All rights reserved.
//

#include "FileIO.hpp"

using namespace std;

int FileIO::readFile(Employee* employeeData[])
{
   //Declaration of variables
   int counter;
   Employee *oldEmployee;
   string employeeID;
   string lastName;
   string firstName;
   string birthday;
   string startDate;
   char gender;
   double salary;
   string idCheck;
   ifstream input;
   
   //Initialization of variables
   counter = 0;

   input.open("Employee.txt");
   
   while (input)
   {
      //reading in employees
      input >> employeeID;
      input >> lastName;
      input >> firstName;
      input >> birthday;
      input >> startDate;
      input >> gender;
      input >> salary;
      
      //creating new employee object
      if (idCheck != employeeID)
      {
         oldEmployee = new Employee(employeeID, lastName, firstName, birthday, startDate, gender, salary);
         employeeData[counter] = oldEmployee;
         idCheck = employeeID;
         counter++;
      }
   }
   counter--;
   input.close();
   
   return counter;
}

void FileIO::writeFile(int element, Employee** employeeData)
{
   //Variable declaration
   ofstream output;
   
   output.open("Employee.txt");
   
   if(output)
   {
      for (int counter = 0; counter <= element; counter++)
      {
         output << employeeData[counter]->getEmployeeID();
         output << " " << employeeData[counter]->getLastName();
         output << " " << employeeData[counter]->getFirstName();
         output << " " << employeeData[counter]->getBirthday();
         output << " " << employeeData[counter]->getStartDate();
         output << " " << employeeData[counter]->getGender();
         output << " " << employeeData[counter]->getSalary();
         output << endl;
      }
   }
   output.close();
}
