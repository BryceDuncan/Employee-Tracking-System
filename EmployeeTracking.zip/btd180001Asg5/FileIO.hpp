//
//  O.hpp
//  btd180001Asg5
//
//  Created by Bryce Duncan on 3/20/20.
//  Copyright © 2020 Duncan Apps. All rights reserved.
//

#ifndef O_hpp
#define O_hpp

#include <stdio.h>
#include <fstream>
#include "Employee.hpp"
#include <string>

using namespace std;

class FileIO
{
public:
   int readFile(Employee* employeeData[]);
   void writeFile(int, Employee**);
};

#endif /* O_hpp */
